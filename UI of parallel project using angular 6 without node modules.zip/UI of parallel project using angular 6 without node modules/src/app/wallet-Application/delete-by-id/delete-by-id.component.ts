import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-by-id',
  templateUrl: './delete-by-id.component.html',
  styleUrls: ['./delete-by-id.component.css']
})
export class DeleteByIdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
