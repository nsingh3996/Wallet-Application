export class Transaction {

    transactionId:Number;
    amount:Number;
    type:String;
    userId:Number;

}

